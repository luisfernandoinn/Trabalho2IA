# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 20:01:19 2020

@author: LuisInnocencio
"""

import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl

#Dimensionamento das variaveis
abertura = ctrl.Antecedent(np.arange(0, 28, 1), 'abertura')
temperatura = ctrl.Antecedent(np.arange(0, 21, 1), 'temperatura')
potencia = ctrl.Consequent(np.arange(0, 49, 1), 'potencia')


#Definição das atribuições de cada variavel
abertura.automf(names=['pouco aberta', 'meio aberta','muito aberta','maximo'])

temperatura.automf(names=['fria', 'pouco fria', 'morna','pouco quente','quente'])

potencia['baixa'] = fuzz.trimf(potencia.universe, [0, 0, 24])
potencia['media'] = fuzz.trimf(potencia.universe, [0, 24, 48])
potencia['alta'] = fuzz.trimf(potencia.universe, [24, 48, 48])


#Regras da defuzzificação
rule1 = ctrl.Rule((temperatura['fria'] | temperatura['pouco fria']) & (abertura['pouco aberta'] | abertura['meio aberta']), potencia['media'])
rule2 = ctrl.Rule((temperatura['fria'] | temperatura['pouco fria']) & (abertura['maximo'] | abertura['muito aberta']), potencia['alta'])
rule3 = ctrl.Rule(temperatura['morna'] , potencia['media'])
rule4 = ctrl.Rule(temperatura['quente'], potencia['baixa'])
rule5 = ctrl.Rule(temperatura['pouco quente'] & abertura ['pouco aberta'] , potencia['baixa'])
rule6 = ctrl.Rule(temperatura['pouco quente'] & (abertura ['muito aberta'] | abertura ['meio aberta'] | abertura ['maximo']), potencia['media'])


#Comados de simulação
potencia_ctrl = ctrl.ControlSystem([rule1, rule2, rule3, rule4, rule5, rule6])
potencia_simulador = ctrl.ControlSystemSimulation(potencia_ctrl)

#Entrada de dados para teste
potencia_simulador.input['abertura'] = 20
potencia_simulador.input['temperatura'] = 1

#Inicio de simulação
potencia_simulador.compute()
print(potencia_simulador.output['potencia'])

#Visualização grafica
abertura.view(sim=potencia_simulador)
temperatura.view(sim=potencia_simulador)
potencia.view(sim=potencia_simulador)
